import * as auth from './auth'
import payment from './payment'

export default {
    ...auth,
    ...payment,
}